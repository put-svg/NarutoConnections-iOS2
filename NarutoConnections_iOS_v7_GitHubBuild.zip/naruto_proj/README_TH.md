# Naruto Connections iOS Launcher — v7

## เพิ่มจาก v6
- ปรับป้ายเวอร์ชันในหน้าจอเป็น iOS v7
- เพิ่ม GitHub Actions workflow เพื่อ Build บน macOS runner โดยไม่ต้องมี Mac ส่วนตัว
- workflow สร้างไฟล์ `NarutoConnections-unsigned.ipa` เป็น Artifact ให้ดาวน์โหลด

## วิธีสั่ง Build ผ่าน iPhone
1. สร้าง repository ส่วนตัวบน GitHub
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้เข้า repository (รวม `.github/workflows/`)
3. เปิดแท็บ **Actions** ของ repository
4. เลือก **Build unsigned iOS IPA** แล้วกด **Run workflow**
5. เมื่อสำเร็จ เปิดรายการ run แล้วดาวน์โหลด Artifact ชื่อ `NarutoConnections-unsigned-IPA`

## ข้อจำกัดสำคัญ
- ต้องมีบัญชี GitHub และเปิดใช้ GitHub Actions; การใช้งาน macOS runner อาจมีข้อจำกัดตามแผน/โควตาของบัญชี
- ไฟล์ที่ workflow สร้างเป็น **unsigned IPA** เท่านั้น ยังติดตั้งผ่าน ESign ไม่ได้จนกว่าจะเซ็นด้วย certificate และ provisioning profile ที่ถูกต้อง และคุณมีสิทธิ์ใช้กับ Bundle ID `com.narutoconnections.launcher`
- ใบรับรอง Rakuten ที่ติดมากับ ESign เป็นขององค์กรอื่น จึงไม่ควรนำมาใช้กับแอปนี้โดยไม่ได้รับอนุญาต
- ปุ่ม PLAY ยังปิดอยู่ เพราะยังไม่มี iOS game runtime
- MetalSurface เป็นเพียงการทดสอบ MTKView/command queue ไม่ใช่ renderer ของเกม
- ยังไม่ได้รัน Xcode build จริงในสภาพแวดล้อมนี้; workflow เป็นช่องทางให้ GitHub macOS runner ทดลอง Compile
