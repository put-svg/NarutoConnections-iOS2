import SwiftUI
import UniformTypeIdentifiers
import CryptoKit
import GameController

struct ContentView: View {
    @State private var showPicker = false
    @State private var folderURL: URL?
    @State private var status = "เลือกโฟลเดอร์เกมเพื่อเริ่มตรวจสอบ"
    @State private var report: [String] = []
    @State private var sha1 = ""
    @State private var controllerStatus = "ไม่พบจอยเกม"
    @State private var showMetalTest = false

    private let expectedSHA1 = "56ad0c6a81071eb2b5188b5ab556adf4ce138563"
    private let expectedSize = 4_448_256

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, Color(red: 0.16, green: 0.04, blue: 0.22)],
                           startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            VStack(spacing: 14) {
                HStack {
                    Image(systemName: "gamecontroller.fill").foregroundStyle(.orange)
                    Text("NARUTO CONNECTIONS").font(.headline.bold())
                    Spacer()
                    Text("iOS v7").font(.caption).foregroundStyle(.secondary)
                }

                Group {
                    if showMetalTest {
                        MetalSurface().overlay(alignment: .topLeading) {
                            Text("METAL SURFACE TEST").font(.caption.bold())
                                .padding(8).background(.black.opacity(0.5))
                        }
                    } else {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(.white.opacity(0.07))
                            .overlay {
                                VStack(spacing: 8) {
                                    Image(systemName: "bolt.horizontal.circle")
                                        .font(.system(size: 44)).foregroundStyle(.orange)
                                    Text("Game runtime not connected").font(.headline)
                                    Text("Metal test checks the iOS graphics surface only.")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                    }
                }
                .frame(height: 170).clipShape(RoundedRectangle(cornerRadius: 16))

                Button { showPicker = true } label: {
                    Label("เลือกโฟลเดอร์เกม", systemImage: "folder")
                        .frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent)

                VStack(alignment: .leading, spacing: 7) {
                    Text(folderURL?.lastPathComponent ?? "ยังไม่ได้เลือกโฟลเดอร์")
                        .font(.headline).lineLimit(1)
                    Text(status).font(.subheadline).foregroundStyle(.secondary)
                    ForEach(report, id: \.self) { Text($0).font(.caption.monospaced()) }
                    if !sha1.isEmpty {
                        Text("SHA-1: \(sha1)").font(.system(size: 10, design: .monospaced))
                            .textSelection(.enabled)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding().background(.white.opacity(0.07))
                .clipShape(RoundedRectangle(cornerRadius: 14))

                HStack {
                    Button("ทดสอบ Metal") { showMetalTest.toggle() }.buttonStyle(.bordered)
                    Button("JOGAR") {
                        status = "ยังไม่มี game runtime สำหรับ iOS จึงยังเปิดเกมไม่ได้"
                    }.buttonStyle(.borderedProminent).tint(.green).disabled(true)
                }

                VStack(spacing: 5) {
                    Text("CONTROLLER").font(.caption.bold()).foregroundStyle(.secondary)
                    HStack {
                        Text("D-PAD  ◀ ▲ ▼ ▶")
                        Spacer()
                        Text("Y   X\nB   A").multilineTextAlignment(.center)
                    }
                    .font(.caption.bold()).padding()
                    .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                    Text(controllerStatus).font(.caption2).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                Text("Launcher / file checker / Metal surface test — not a playable port")
                    .font(.system(size: 9)).foregroundStyle(.secondary)
            }
            .padding()
            .foregroundStyle(.white)
        }
        .fileImporter(isPresented: $showPicker, allowedContentTypes: [.folder],
                      allowsMultipleSelection: false, onCompletion: inspect)
        .onAppear(perform: observeControllers)
    }

    private func inspect(_ result: Result<[URL], Error>) {
        do {
            guard let folder = try result.get().first else { return }
            let access = folder.startAccessingSecurityScopedResource()
            defer { if access { folder.stopAccessingSecurityScopedResource() } }
            folderURL = folder
            report = []
            sha1 = ""

            for name in ["default.xex", "data", "nxeart", "Content"] {
                let url = folder.appendingPathComponent(name)
                var isDir: ObjCBool = false
                let exists = FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir)
                report.append("\(exists ? "พบ" : "ไม่พบ") \(name)")
            }

            let xex = folder.appendingPathComponent("default.xex")
            guard FileManager.default.fileExists(atPath: xex.path) else {
                status = "ไม่พบ default.xex"
                return
            }
            let attrs = try FileManager.default.attributesOfItem(atPath: xex.path)
            let size = (attrs[.size] as? NSNumber)?.intValue ?? 0
            sha1 = try Self.hash(xex)
            status = size == expectedSize && sha1 == expectedSHA1
                ? "default.xex ตรงกับค่าอ้างอิงของ Port Nativo"
                : "พบ default.xex แต่ hash หรือขนาดไม่ตรง"
        } catch {
            status = "ตรวจสอบไม่สำเร็จ: \(error.localizedDescription)"
        }
    }

    private static func hash(_ url: URL) throws -> String {
        let file = try FileHandle(forReadingFrom: url)
        defer { try? file.close() }
        var hasher = Insecure.SHA1()
        while true {
            let chunk = file.readData(ofLength: 1024 * 1024)
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }

    private func observeControllers() {
        NotificationCenter.default.addObserver(forName: .GCControllerDidConnect, object: nil, queue: .main) { _ in
            controllerStatus = "เชื่อมต่อจอยแล้ว"
        }
        NotificationCenter.default.addObserver(forName: .GCControllerDidDisconnect, object: nil, queue: .main) { _ in
            controllerStatus = GCController.controllers().isEmpty ? "ไม่พบจอยเกม" : "ยังมีจอยเชื่อมต่อ"
        }
        controllerStatus = GCController.controllers().isEmpty ? "ไม่พบจอยเกม" : "เชื่อมต่อจอยแล้ว"
    }
}
